<x-app-layout>
    <x-slot name="header">
        <h2 class="h4 font-weight-bold text-dark mb-0">User Management</h2>
    </x-slot>

    <div class="card shadow-sm border-0 rounded-4 overflow-hidden mb-4">
        <div class="card-header bg-white py-3 px-4 border-bottom d-flex justify-content-between align-items-center">
            <h5 class="mb-0 fw-bold">System Users</h5>
            <a href="{{ route('super-admin.users.create') }}" class="btn btn-primary rounded-pill px-4 fw-bold shadow-sm">
                <i class="bi bi-person-plus-fill me-1"></i> Create User
            </a>
        </div>
        
        <div class="card-body p-0">
            @if (session('success'))
                <div class="p-4 py-3 alert alert-success border-0 rounded-0 mb-0 shadow-sm">
                    <i class="bi bi-check-circle-fill me-2"></i> {{ session('success') }}
                </div>
            @endif
            @if (session('error'))
                <div class="p-4 py-3 alert alert-danger border-0 rounded-0 mb-0 shadow-sm">
                    <i class="bi bi-exclamation-circle-fill me-2"></i> {{ session('error') }}
                </div>
            @endif

            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-light">
                        <tr>
                            <th class="ps-4 py-3 text-uppercase small fw-bold text-muted border-0">Name</th>
                            <th class="py-3 text-uppercase small fw-bold text-muted border-0">Email</th>
                            <th class="py-3 text-uppercase small fw-bold text-muted border-0">Role</th>
                            <th class="py-3 text-uppercase small fw-bold text-muted border-0 text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody class="border-top-0">
                        @forelse($users as $u)
                            <tr>
                                <td class="ps-4 py-4 fw-bold text-dark">{{ $u->name }}</td>
                                <td class="py-4 text-primary fw-medium">{{ $u->email }}</td>
                                <td class="py-4">
                                    @php
                                        $roleBadges = [
                                            'super-admin' => 'bg-danger',
                                            'boesl-admin' => 'bg-info',
                                            'bhc-admin' => 'bg-success',
                                        ];
                                    @endphp
                                    @foreach($u->roles as $role)
                                        <span class="badge rounded-pill {{ $roleBadges[$role->name] ?? 'bg-secondary' }} px-3 py-1">
                                            {{ $role->name }}
                                        </span>
                                    @endforeach
                                    @if($u->roles->isEmpty())
                                        <span class="text-muted small">No Role</span>
                                    @endif
                                </td>
                                <td class="py-4 text-center">
                                    <div class="d-flex justify-content-center gap-2">
                                        <a href="{{ route('super-admin.users.edit', $u) }}" class="btn btn-outline-primary btn-sm rounded-pill px-3 fw-bold">Edit</a>
                                        <form method="POST" action="{{ route('super-admin.users.destroy', $u) }}" onsubmit="return confirm('Delete this user?')">
                                            @csrf @method('DELETE')
                                            <button class="btn btn-outline-danger btn-sm rounded-pill px-3 fw-bold">Delete</button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="4" class="text-center py-5 text-muted">
                                    No users found.
                                </td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</x-app-layout>
