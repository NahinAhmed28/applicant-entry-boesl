<x-app-layout>
    <x-slot name="header">
        <h2 class="h4 font-weight-bold text-dark mb-0">
            {{ __('Manage Applicant') }} - <span class="text-primary">{{ $applicant->applicant_name }}</span>
        </h2>
    </x-slot>

    <div class="py-5 bg-light min-vh-100">
        <div class="container max-w-4xl">
            <div class="mb-4">
                <a href="{{ route('bhc.applicants.index') }}" class="btn btn-link text-decoration-none p-0 fw-bold text-muted">
                    <i class="bi bi-arrow-left me-1"></i> Back to List
                </a>
            </div>

            <div class="card shadow-sm border-0 rounded-4 overflow-hidden mb-4">
                <div class="card-header bg-white py-3 border-bottom">
                    <h5 class="mb-0 fw-bold">Update Information</h5>
                </div>
                <div class="card-body p-4">
                    <form method="POST" action="{{ route('bhc.applicants.update', $applicant) }}">
                        @csrf
                        @method('PUT')
                        <div class="row g-4">
                            <div class="col-md-6">
                                <label class="form-label fw-bold text-muted small text-uppercase">BHC No</label>
                                <input type="text" class="form-control rounded-3 bg-light" value="{{ $applicant->bhc_no }}" readonly disabled>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold text-muted small text-uppercase">Passport No</label>
                                <input type="text" class="form-control rounded-3 bg-light" value="{{ $applicant->passport_no }}" readonly disabled>
                            </div>
                            <div class="col-md-6">
                                <label for="phone_number" class="form-label fw-bold text-muted small text-uppercase">Phone Number</label>
                                <input type="text" name="phone_number" id="phone_number" class="form-control rounded-3 border-primary-subtle" value="{{ old('phone_number', $applicant->phone_number) }}" placeholder="e.g. +673 1234567">
                                <div class="form-text small">Primary contact number for the applicant.</div>
                            </div>
                            <div class="col-md-6">
                                <label for="registered_at" class="form-label fw-bold text-muted small text-uppercase">Registration Date</label>
                                <input type="date" name="registered_at" id="registered_at" class="form-control rounded-3 border-primary-subtle" value="{{ old('registered_at', $applicant->registered_at?->format('Y-m-d')) }}">
                                <div class="form-text small">Date the applicant was officially registered at BHC.</div>
                            </div>
                        </div>
                        <div class="mt-5 d-flex justify-content-end gap-3">
                            <a href="{{ route('bhc.applicants.index') }}" class="btn btn-outline-secondary px-4 rounded-pill fw-bold">Cancel</a>
                            <button type="submit" class="btn btn-primary px-5 rounded-pill fw-bold shadow-sm">Save Changes</button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Tracking Card -->
            <div class="card shadow-sm border-0 rounded-4 overflow-hidden">
                <div class="card-header bg-white py-3 border-bottom">
                    <h5 class="mb-0 fw-bold">Status & Tracking</h5>
                </div>
                <div class="card-body p-4">
                    <form method="POST" action="{{ route('bhc.applicants.updateTracking', $applicant) }}">
                        @csrf
                        @method('PATCH')
                        <div class="row g-4 align-items-center">
                            <div class="col-md-6">
                                <div class="form-check form-switch custom-switch py-2">
                                    <input class="form-check-input" type="checkbox" name="ic_card_received" id="ic_card_received" @checked($applicant->ic_received_at)>
                                    <label class="form-check-label fw-bold ms-2" for="ic_card_received">IC Card Received</label>
                                </div>
                                @if($applicant->ic_received_at)
                                    <div class="text-success small ms-5 ps-3 fw-medium">
                                        <i class="bi bi-clock-history"></i> Received on {{ $applicant->ic_received_at->format('d M, Y H:i') }}
                                    </div>
                                @endif
                            </div>
                            <div class="col-md-6">
                                <div class="form-check form-switch custom-switch py-2">
                                    <input class="form-check-input" type="checkbox" name="insurance_received" id="insurance_received" @checked($applicant->insurance_received_at)>
                                    <label class="form-check-label fw-bold ms-2" for="insurance_received">Insurance Received</label>
                                </div>
                                @if($applicant->insurance_received_at)
                                    <div class="text-success small ms-5 ps-3 fw-medium">
                                        <i class="bi bi-clock-history"></i> Received on {{ $applicant->insurance_received_at->format('d M, Y H:i') }}
                                    </div>
                                @endif
                            </div>
                        </div>
                        <div class="mt-5 text-end">
                            <button type="submit" class="btn btn-success px-5 rounded-pill fw-bold shadow-sm">Update Tracking</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <style>
        .rounded-4 { border-radius: 1rem !important; }
        .custom-switch .form-check-input { width: 3rem; height: 1.5rem; cursor: pointer; }
        .border-primary-subtle { border-color: #cfe2ff !important; }
        .form-control:focus { box-shadow: 0 0 0 0.25rem rgba(13, 110, 253, 0.1); }
    </style>
</x-app-layout>
