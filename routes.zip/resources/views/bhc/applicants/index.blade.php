<x-app-layout>
    <x-slot name="header">
        <h2 class="h4 font-weight-bold text-dark mb-0">
            {{ __('BHC Applicants List') }}
        </h2>
    </x-slot>

    <div class="py-4 bg-light min-vh-100">
        <div class="container-fluid max-w-7xl mx-auto px-4">
            @if (session('success'))
                <div class="alert alert-success alert-dismissible fade show rounded-3 shadow-sm border-0 mb-4" role="alert">
                    <i class="bi bi-check-circle-fill me-2"></i> {{ session('success') }}
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            @endif

            <div class="card shadow-sm border-0 rounded-4 overflow-hidden" x-data="{ filterOpen: {{ request()->hasAny(['bhc_no', 'applicant_name', 'passport_no', 'flight_date', 'status', 'registered_at', 'agency_name', 'company_name']) ? 'true' : 'false' }} }">
                <div class="card-header bg-white py-4 px-4 border-bottom d-flex justify-content-between align-items-center">
                    <h5 class="mb-0 fw-bold text-dark">Total Applicants Registered</h5>
                    <button type="button" @click="filterOpen = !filterOpen" class="btn btn-outline-primary fw-bold rounded-pill px-4 shadow-sm">
                        <i class="bi bi-filter me-1"></i> Filter Search
                    </button>
                </div>

                <div class="card-body p-0">
                    <!-- Filters -->
                    <div class="p-4 bg-light border-bottom" x-show="filterOpen" x-cloak x-transition>
                        <form method="GET" action="{{ route('bhc.applicants.index') }}">
                            <div class="row g-3">
                                <div class="col-md-3">
                                    <label class="form-label small fw-bold text-muted text-uppercase mb-1">BHC No / Passport</label>
                                    <div class="input-group input-group-sm">
                                        <input type="text" name="bhc_no" value="{{ request('bhc_no') }}" placeholder="BHC No" class="form-control rounded-start-pill px-3">
                                        <input type="text" name="passport_no" value="{{ request('passport_no') }}" placeholder="Passport" class="form-control rounded-end-pill px-3">
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label small fw-bold text-muted text-uppercase mb-1">Applicant Name</label>
                                    <input type="text" name="applicant_name" value="{{ request('applicant_name') }}" placeholder="Search by name" class="form-control form-control-sm rounded-pill px-3">
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label small fw-bold text-muted text-uppercase mb-1">Agency / Company</label>
                                    <div class="input-group input-group-sm">
                                        <input type="text" name="agency_name" value="{{ request('agency_name') }}" placeholder="Agency" class="form-control rounded-start-pill px-3">
                                        <input type="text" name="company_name" value="{{ request('company_name') }}" placeholder="Company" class="form-control rounded-end-pill px-3">
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label small fw-bold text-muted text-uppercase mb-1">Status</label>
                                    <select name="status" class="form-select form-select-sm rounded-pill px-3">
                                        <option value="">All Statuses</option>
                                        <option value="pending" @selected(request('status') === 'pending')>Pending</option>
                                        <option value="sent_to_bhc" @selected(request('status') === 'sent_to_bhc')>Sent to BHC</option>
                                        <option value="registered" @selected(request('status') === 'registered')>Registered</option>
                                        <option value="ic_received" @selected(request('status') === 'ic_received')>IC Received</option>
                                        <option value="insurance_received" @selected(request('status') === 'insurance_received')>Insurance Received</option>
                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label small fw-bold text-muted text-uppercase mb-1">Flight Date</label>
                                    <input type="date" name="flight_date" value="{{ request('flight_date') }}" class="form-control form-control-sm rounded-pill px-3">
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label small fw-bold text-muted text-uppercase mb-1">Registered Date</label>
                                    <input type="date" name="registered_at" value="{{ request('registered_at') }}" class="form-control form-control-sm rounded-pill px-3">
                                </div>
                                <div class="col-md-6 d-flex align-items-end gap-2">
                                    <button type="submit" class="btn btn-blue btn-sm rounded-pill flex-grow-1 fw-bold shadow-sm">
                                        <i class="bi bi-search me-1"></i> Apply Filter
                                    </button>
                                    <a href="{{ route('bhc.applicants.index') }}" class="btn btn-outline-secondary btn-sm rounded-pill fw-bold" title="Reset Filters">
                                        <i class="bi bi-x-lg"></i>
                                    </a>
                                </div>
                            </div>
                        </form>
                    </div>

                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="bg-light">
                                <tr>
                                    <th class="ps-4 py-3 text-uppercase small fw-extrabold text-muted">BHC No</th>
                                    <th class="py-3 text-uppercase small fw-extrabold text-muted tracking-wider">Applicant Name</th>
                                    <th class="py-3 text-uppercase small fw-extrabold text-muted tracking-wider">ID Details</th>
                                    <th class="py-3 text-uppercase small fw-extrabold text-muted tracking-wider">Flight Date</th>
                                    <th class="py-3 text-uppercase small fw-extrabold text-muted tracking-wider text-center">Status</th>
                                    <th class="py-3 text-uppercase small fw-extrabold text-muted tracking-wider text-center">Registration</th>
                                    <th class="py-3 text-uppercase small fw-extrabold text-muted tracking-wider text-center">Actions</th>
                                </tr>
                            </thead>
                            <tbody class="border-top-0">
                                @foreach($applicants as $applicant)
                                    <tr>
                                        <td class="ps-4 py-4 fw-bold text-dark">{{ $applicant->bhc_no }}</td>
                                        <td class="py-4">
                                            <span class="fw-bold d-block text-dark">{{ $applicant->applicant_name }}</span>
                                            <span class="text-primary small fw-medium">{{ $applicant->phone_number ?? 'No phone' }}</span>
                                        </td>
                                        <td class="py-4">
                                            <span class="badge bg-light text-dark border rounded-pill px-3 fw-medium">Passport: {{ $applicant->passport_no }}</span>
                                        </td>
                                        <td class="py-4">
                                            @if($applicant->flight_date)
                                                <span class="text-dark fw-medium"><i class="bi bi-calendar2-event me-1 text-muted"></i> {{ $applicant->flight_date->format('Y-m-d') }}</span>
                                            @else
                                                <span class="text-secondary small">Pending</span>
                                            @endif
                                        </td>
                                        <td class="py-4 text-center">
                                            @php
                                                $statusColors = [
                                                    'pending' => 'bg-secondary',
                                                    'sent_to_bhc' => 'bg-info',
                                                    'registered' => 'bg-success',
                                                    'ic_received' => 'bg-primary',
                                                    'insurance_received' => 'bg-warning text-dark',
                                                ];
                                                $statusClass = $statusColors[$applicant->status] ?? 'bg-secondary';
                                            @endphp
                                            <span class="badge rounded-pill {{ $statusClass }} px-3 py-2 text-uppercase fw-bold shadow-sm" style="font-size: 0.75rem; min-width: 120px;">
                                                {{ str_replace('_', ' ', $applicant->status) }}
                                            </span>
                                        </td>
                                        <td class="py-4 text-center">
                                            @if($applicant->registered_at)
                                                <span class="text-success fw-bold small"><i class="bi bi-patch-check-fill me-1"></i> {{ $applicant->registered_at->format('Y-m-d') }}</span>
                                            @else
                                                <span class="text-warning small fw-bold">NOT REGISTERED</span>
                                            @endif
                                        </td>
                                        <td class="py-4 text-center pe-4">
                                            <div class="d-flex justify-content-center gap-2">
                                                <a href="{{ route('bhc.applicants.edit', $applicant) }}" class="btn btn-outline-primary btn-sm rounded-pill px-3 fw-bold">Manage</a>
                                                @if(!$applicant->registered_at)
                                                    <form action="{{ route('bhc.applicants.markRegistered', $applicant) }}" method="POST" class="d-inline">
                                                        @csrf
                                                        <button type="submit" class="btn btn-success btn-sm rounded-pill px-3 fw-bold" onclick="return confirm('Confirm registration for this applicant?')">Register</button>
                                                    </form>
                                                @endif
                                            </div>
                                        </td>
                                    </tr>
                                @endforeach
                                @if($applicants->isEmpty())
                                    <tr>
                                        <td colspan="7" class="text-center py-5 text-muted">
                                            <i class="bi bi-search h1 d-block mb-3 opacity-25"></i>
                                            <span class="fw-bold">No applicants found matching your criteria</span>
                                        </td>
                                    </tr>
                                @endif
                            </tbody>
                        </table>
                    </div>
                </div>

                @if($applicants->hasPages())
                    <div class="card-footer bg-white py-3 border-top-0 d-flex justify-content-center">
                        <div class="bootstrap-pagination-wrapper">
                            {{ $applicants->links('pagination::bootstrap-5') }}
                        </div>
                    </div>
                @endif
            </div>
        </div>
    </div>

    <style>
        .rounded-4 { border-radius: 1rem !important; }
        .fw-extrabold { font-weight: 800; }
        .btn-blue { background-color: #0d6efd; color: white; border-radius: 50rem; transition: all 0.2s; }
        .btn-blue:hover { background-color: #0b5ed7; color: white; transform: translateY(-1px); box-shadow: 0 4px 6px rgba(13, 110, 253, 0.2); }
        .tracking-wider { letter-spacing: 0.05em; }
        .table-hover tbody tr:hover { background-color: rgba(0,0,0,.015); }
    </style>
</x-app-layout>
