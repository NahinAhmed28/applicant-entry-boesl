<x-app-layout>
    <x-slot name="header">
        <h2 class="h4 font-weight-bold text-dark mb-0">
            {{ __('Boesl Applicants') }}
        </h2>
    </x-slot>

    <div class="py-4 bg-light min-vh-100">
        <div class="container-fluid max-w-7xl mx-auto px-4" x-data="{ activeSection: null }">
            <!-- Action Sections Toggle -->
            <div class="mb-4 d-flex gap-2">
                <button class="btn btn-primary fw-bold px-4 rounded-pill shadow-sm" type="button" @click="activeSection = activeSection === 'manual' ? null : 'manual'">
                    Manual Entry
                </button>
                <button class="btn btn-success fw-bold px-4 rounded-pill shadow-sm" type="button" @click="activeSection = activeSection === 'batch' ? null : 'batch'">
                    Batch Import
                </button>
            </div>

            <!-- Manual Entry Section (Hidden by default) -->
            <div x-show="activeSection === 'manual'" x-cloak x-transition class="card shadow-sm border-0 rounded-4 mb-4">
                <div class="card-header bg-primary text-white rounded-top-4 py-3 d-flex justify-content-between align-items-center">
                    <h5 class="mb-0 fw-bold">Add New Applicant Manually</h5>
                    <button class="btn btn-sm btn-light rounded-pill" @click="activeSection = null">Close</button>
                </div>
                <div class="card-body p-4">
                    <form method="POST" action="{{ route('boesl.applicants.store') }}">
                        @csrf
                        <div class="row g-3">
                            <div class="col-md-4">
                                <label class="form-label fw-bold text-muted small text-uppercase">BHC-No</label>
                                <input type="text" name="bhc_no" class="form-control rounded-3" placeholder="Enter BHC No" required>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label fw-bold text-muted small text-uppercase">Applicant Name</label>
                                <input type="text" name="applicant_name" class="form-control rounded-3" placeholder="Enter Name" required>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label fw-bold text-muted small text-uppercase">Passport No</label>
                                <input type="text" name="passport_no" class="form-control rounded-3" placeholder="Enter Passport" required>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label fw-bold text-muted small text-uppercase">Agency Name</label>
                                <input type="text" name="agency_name" class="form-control rounded-3" placeholder="Enter Agency" required>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label fw-bold text-muted small text-uppercase">Company Name</label>
                                <input type="text" name="company_name" class="form-control rounded-3" placeholder="Enter Company" required>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label fw-bold text-muted small text-uppercase">Flight Date</label>
                                <input type="date" name="flight_date" class="form-control rounded-3" required>
                            </div>
                        </div>
                        <div class="mt-4 text-end">
                            <button type="submit" class="btn btn-primary px-5 fw-bold rounded-pill">Submit Applicant</button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Batch Import Section (Hidden by default) -->
            <div x-show="activeSection === 'batch'" x-cloak x-transition class="card shadow-sm border-0 rounded-4 mb-4">
                <div class="card-header bg-success text-white rounded-top-4 py-3 d-flex justify-content-between align-items-center">
                    <h5 class="mb-0 fw-bold">Batch Applicant Import</h5>
                    <button class="btn btn-sm btn-light rounded-pill" @click="activeSection = null">Close</button>
                </div>
                <div class="card-body p-4" x-data="{ fileName: '' }">
                    <div class="row align-items-center">
                        <div class="col-md-6 mb-3 mb-md-0">
                            <p class="text-muted small mb-3">Upload your Excel file (.xlsx or .csv) to import multiple applicants at once. Make sure to use the correct template format.</p>
                            <a href="{{ route('boesl.applicants.template') }}" class="btn btn-outline-success btn-sm fw-bold rounded-pill px-3">
                                <i class="bi bi-download"></i> Download Template
                            </a>
                        </div>
                        <div class="col-md-6">
                            <form action="{{ route('boesl.applicants.import') }}" method="POST" enctype="multipart/form-data">
                                @csrf
                                <div class="mb-3">
                                    <div class="input-group">
                                        <input type="file" name="excel_file" id="excel_file" class="form-control rounded-start-pill" required @change="fileName = $event.target.files[0].name">
                                        <button class="btn btn-success px-4 rounded-end-pill fw-bold" type="submit">Import</button>
                                    </div>
                                    <div class="form-text mt-2 text-success fw-medium" x-show="fileName" x-text="'Selected: ' + fileName"></div>
                                </div>
                            </form>
                        </div>
                    </div>

                    <!-- Import Errors -->
                    @if (session()->has('import_errors'))
                        <div class="alert alert-danger mt-4 rounded-3 p-3">
                            <p class="fw-bold mb-2 small"><i class="bi bi-exclamation-triangle"></i> Import blocked by validation rules:</p>
                            <ul class="list-unstyled mb-0 small overflow-auto" style="max-height: 200px;">
                                @foreach (session('import_errors') as $failure)
                                    <li class="mb-2 d-flex align-items-start">
                                        <span class="badge bg-danger rounded-pill me-2 mt-1">{{ $failure->row() }}</span>
                                        <span>{{ implode(', ', $failure->errors()) }}</span>
                                    </li>
                                @endforeach
                            </ul>
                        </div>
                    @endif
                </div>
            </div>

            <!-- Feedback Alerts -->
            @if (session('success'))
                <div class="alert alert-success alert-dismissible fade show rounded-3 shadow-sm border-0 mb-4" role="alert">
                    <i class="bi bi-check-circle-fill me-2"></i> {{ session('success') }}
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            @endif

            @if (session('error'))
                <div class="alert alert-danger alert-dismissible fade show rounded-3 shadow-sm border-0 mb-4" role="alert">
                    <i class="bi bi-exclamation-circle-fill me-2"></i> {{ session('error') }}
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            @endif

            <!-- Main Registry Card -->
            <div class="card shadow-sm border-0 rounded-4 overflow-hidden mb-5" x-data="{ filterOpen: false }">
                <div class="card-header bg-white py-4 px-4 border-bottom d-flex flex-wrap justify-content-between align-items-center gap-3">
                    <div>
                        <h4 class="fw-extrabold text-dark mb-1">Applicant Registry</h4>
                        <p class="text-muted small mb-0">List of all applicants submitted by you.</p>
                    </div>
                    <button class="btn btn-outline-primary fw-bold rounded-pill px-4 shadow-sm" @click="filterOpen = !filterOpen">
                        <i class="bi bi-filter me-1"></i> Filter Search
                    </button>
                </div>

                <div class="card-body p-0">
                    <!-- Filters -->
                    <div class="p-4 bg-light border-bottom" x-show="filterOpen" x-cloak x-transition>
                        <form method="GET" action="{{ route('boesl.applicants.index') }}">
                            <div class="row g-3">
                                <div class="col-md-3">
                                    <label class="form-label small fw-bold text-muted text-uppercase mb-1">BHC No / Passport</label>
                                    <div class="input-group input-group-sm">
                                        <input type="text" name="bhc_no" value="{{ request('bhc_no') }}" placeholder="BHC No" class="form-control rounded-start-pill px-3">
                                        <input type="text" name="passport_no" value="{{ request('passport_no') }}" placeholder="Passport" class="form-control rounded-end-pill px-3">
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label small fw-bold text-muted text-uppercase mb-1">Applicant Name</label>
                                    <input type="text" name="applicant_name" value="{{ request('applicant_name') }}" placeholder="Search by name" class="form-control form-control-sm rounded-pill px-3">
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label small fw-bold text-muted text-uppercase mb-1">Agency / Company</label>
                                    <div class="input-group input-group-sm">
                                        <input type="text" name="agency_name" value="{{ request('agency_name') }}" placeholder="Agency" class="form-control rounded-start-pill px-3">
                                        <input type="text" name="company_name" value="{{ request('company_name') }}" placeholder="Company" class="form-control rounded-end-pill px-3">
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label small fw-bold text-muted text-uppercase mb-1">Status</label>
                                    <select name="status" class="form-select form-select-sm rounded-pill px-3">
                                        <option value="">All Statuses</option>
                                        <option value="pending" @selected(request('status') === 'pending')>Pending</option>
                                        <option value="sent_to_bhc" @selected(request('status') === 'sent_to_bhc')>Sent to BHC</option>
                                        <option value="registered" @selected(request('status') === 'registered')>Registered</option>
                                        <option value="ic_received" @selected(request('status') === 'ic_received')>IC Received</option>
                                        <option value="insurance_received" @selected(request('status') === 'insurance_received')>Insurance Received</option>
                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label small fw-bold text-muted text-uppercase mb-1">Flight Date</label>
                                    <input type="date" name="flight_date" value="{{ request('flight_date') }}" class="form-control form-control-sm rounded-pill px-3">
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label small fw-bold text-muted text-uppercase mb-1">Registered Date</label>
                                    <input type="date" name="registered_at" value="{{ request('registered_at') }}" class="form-control form-control-sm rounded-pill px-3">
                                </div>
                                <div class="col-md-6 d-flex align-items-end gap-2">
                                    <button type="submit" class="btn btn-primary btn-sm rounded-pill flex-grow-1 fw-bold shadow-sm">
                                        <i class="bi bi-search me-1"></i> Apply Filter
                                    </button>
                                    <a href="{{ route('boesl.applicants.index') }}" class="btn btn-outline-secondary btn-sm rounded-pill fw-bold" title="Reset Filters">
                                        <i class="bi bi-x-lg"></i>
                                    </a>
                                </div>
                            </div>
                        </form>
                    </div>

                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="bg-light">
                                <tr>
                                    <th class="ps-4 py-3 text-uppercase small fw-bold text-muted tracking-wider border-0">BHC No</th>
                                    <th class="py-3 text-uppercase small fw-bold text-muted tracking-wider border-0">Applicant Info</th>
                                    <th class="py-3 text-uppercase small fw-bold text-muted tracking-wider border-0">Agency/Company</th>
                                    <th class="py-3 text-uppercase small fw-bold text-muted tracking-wider border-0">Flight Date</th>
                                    <th class="py-3 text-uppercase small fw-bold text-muted tracking-wider border-0 text-center">Status</th>
                                    <th class="py-3 text-uppercase small fw-bold text-muted tracking-wider border-0 text-center">Actions</th>
                                </tr>
                            </thead>
                            <tbody class="border-top-0">
                                @forelse($applicants as $applicant)
                                    <tr>
                                        <td class="ps-4 py-4">
                                            <span class="fw-bold text-primary">{{ $applicant->bhc_no }}</span><br>
                                            <span class="text-muted small fw-medium">{{ $applicant->passport_no }}</span>
                                        </td>
                                        <td class="py-4">
                                            <span class="fw-bold text-dark">{{ $applicant->applicant_name }}</span>
                                        </td>
                                        <td class="py-4">
                                            <span class="text-dark d-block fw-medium">{{ $applicant->agency_name }}</span>
                                            <span class="text-muted small">{{ $applicant->company_name }}</span>
                                        </td>
                                        <td class="py-4">
                                            @if($applicant->flight_date)
                                                <span class="text-dark fw-medium"><i class="bi bi-airplane me-1 text-muted"></i> {{ $applicant->flight_date->format('d M, Y') }}</span>
                                            @else
                                                <span class="text-secondary small">Not set</span>
                                            @endif
                                        </td>
                                        <td class="py-4 text-center">
                                            @php
                                                $statusColors = [
                                                    'pending' => 'bg-secondary',
                                                    'sent_to_bhc' => 'bg-info',
                                                    'registered' => 'bg-success',
                                                    'ic_received' => 'bg-primary',
                                                    'insurance_received' => 'bg-warning text-dark',
                                                ];
                                                $statusBadge = $statusColors[$applicant->status] ?? 'bg-secondary';
                                            @endphp
                                            <span class="badge rounded-pill {{ $statusBadge }} px-3 py-2 text-uppercase fw-bold shadow-sm" style="font-size: 0.7rem; min-width: 100px;">
                                                {{ str_replace('_', ' ', $applicant->status) }}
                                            </span>
                                        </td>
                                        <td class="py-4 text-center">
                                            <span class="text-muted italic small fw-bold"><i class="bi bi-lock-fill me-1"></i> READ ONLY</span>
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="6" class="text-center py-5 text-muted">
                                            <i class="bi bi-folder2-open h1 d-block mb-3 opacity-25"></i>
                                            <span class="fw-bold">No matching data found</span>
                                        </td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>

                @if($applicants->hasPages())
                    <div class="card-footer bg-white py-3 border-top-0 d-flex justify-content-center">
                        <div class="bootstrap-pagination-wrapper">
                            {{ $applicants->links('pagination::bootstrap-5') }}
                        </div>
                    </div>
                @endif
            </div>
        </div>
    </div>
    
    <style>
        .fw-extrabold { font-weight: 800; }
        .rounded-4 { border-radius: 1rem !important; }
        .rounded-top-4 { border-top-left-radius: 1rem !important; border-top-right-radius: 1rem !important; }
        .rounded-start-pill { border-top-left-radius: 50rem !important; border-bottom-left-radius: 50rem !important; }
        .rounded-end-pill { border-top-right-radius: 50rem !important; border-bottom-right-radius: 50rem !important; }
        .tracking-wider { letter-spacing: 0.05em; }
        .input-group > .form-control { border-width: 1px; }
        .input-group > .btn { border-width: 1px; }
        /* Reset table hover */
        .table-hover tbody tr:hover { background-color: rgba(0,0,0,.02); }
    </style>
</x-app-layout>
