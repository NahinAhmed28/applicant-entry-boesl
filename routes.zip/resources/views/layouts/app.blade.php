<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>Brunei Worker Management</title>

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    
    <!-- Bootstrap 5 JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    @vite(['resources/js/app.js'])

    <style>
        :root {
            --sidebar-width: 260px;
            --sidebar-collapsed-width: 70px;
            --primary-color: #0d6efd;
            --bg-sidebar: #0f172a;
            --bg-body: #f8fafc;
        }

        body {
            font-family: 'Inter', sans-serif;
            background-color: var(--bg-body);
        }

        #wrapper {
            display: flex;
            width: 100%;
            align-items: stretch;
        }

        #sidebar {
            min-width: var(--sidebar-width);
            max-width: var(--sidebar-width);
            background: var(--bg-sidebar);
            color: #fff;
            transition: all 0.3s;
            min-height: 100vh;
            position: fixed;
            z-index: 1000;
        }

        #sidebar.active {
            min-width: var(--sidebar-collapsed-width);
            max-width: var(--sidebar-collapsed-width);
        }

        #sidebar .sidebar-header {
            padding: 20px;
            background: rgba(0,0,0,0.1);
            border-bottom: 1px solid rgba(255,255,255,0.05);
        }

        #sidebar .sidebar-header strong {
            display: block;
        }

        #sidebar.active .sidebar-header strong {
            display: none;
        }

        #sidebar.active .sidebar-header span {
            display: block;
            text-align: center;
            font-weight: 800;
        }

        #sidebar ul.components {
            padding: 20px 0;
        }

        #sidebar ul li a {
            padding: 12px 20px;
            font-size: 0.9rem;
            display: block;
            color: rgba(255,255,255,0.7);
            text-decoration: none;
            transition: all 0.2s;
            border-left: 3px solid transparent;
        }

        #sidebar ul li a:hover {
            color: #fff;
            background: rgba(255,255,255,0.05);
        }

        #sidebar ul li.active > a {
            color: #fff;
            background: rgba(255,255,255,0.1);
            border-left-color: var(--primary-color);
        }

        #sidebar.active ul li a span {
            display: none;
        }

        #sidebar.active ul li a i {
            margin-right: 0;
            display: block;
            text-align: center;
            font-size: 1.2rem;
        }

        #content {
            width: 100%;
            padding: 0;
            min-height: 100vh;
            transition: all 0.3s;
            margin-left: var(--sidebar-width);
        }

        #content.active {
            margin-left: var(--sidebar-collapsed-width);
        }

        .navbar {
            padding: 15px 10px;
            background: #fff;
            border: none;
            border-radius: 0;
            box-shadow: 0 2px 5px 0 rgba(0,0,0,0.05);
        }

        .nav-icon {
            margin-right: 15px;
            width: 20px;
        }

        [x-cloak] { display: none !important; }

        @media (max-width: 992px) {
            #sidebar {
                margin-left: calc(-1 * var(--sidebar-width));
            }
            #sidebar.active {
                margin-left: 0 !important;
                min-width: var(--sidebar-width);
                max-width: var(--sidebar-width);
            }
            #content {
                margin-left: 0;
            }
            #content.active {
                margin-left: 0;
            }
        }
    </style>
</head>
<body x-data="{ sidebarActive: false }">
    <div id="wrapper">
        <!-- Sidebar -->
        <nav id="sidebar" :class="{ 'active': sidebarActive }">
            <div class="sidebar-header">
                <strong>Brunei Worker Information Record Manager</strong>
                <span style="display: none;">BW</span>
            </div>

            <ul class="list-unstyled components">
                <li class="{{ request()->routeIs('dashboard') ? 'active' : '' }}">
                    <a href="{{ route('dashboard') }}">
                        <i class="bi bi-speedometer2 nav-icon"></i>
                        <span>Dashboard</span>
                    </a>
                </li>

                @if(auth()->user()->hasAnyRole(['boesl-admin', 'super-admin']))
                <li class="{{ request()->routeIs('boesl.*') ? 'active' : '' }}">
                    <a href="{{ route('boesl.applicants.index') }}">
                        <i class="bi bi-person-lines-fill nav-icon"></i>
                        <span>BOESL Applicants</span>
                    </a>
                </li>
                @endif

                @if(auth()->user()->hasAnyRole(['bhc-admin', 'super-admin']))
                <li class="{{ request()->routeIs('bhc.*') ? 'active' : '' }}">
                    <a href="{{ route('bhc.applicants.index') }}">
                        <i class="bi bi-building-check nav-icon"></i>
                        <span>BHC Applicants</span>
                    </a>
                </li>
                @endif

                @role('super-admin')
                <li class="{{ request()->routeIs('super-admin.users.*') ? 'active' : '' }}">
                    <a href="{{ route('super-admin.users.index') }}">
                        <i class="bi bi-people nav-icon"></i>
                        <span>User Management</span>
                    </a>
                </li>
                @endrole

                <li class="{{ request()->routeIs('profile.*') ? 'active' : '' }}">
                    <a href="{{ route('profile.edit') }}">
                        <i class="bi bi-person-circle nav-icon"></i>
                        <span>Profile</span>
                    </a>
                </li>

                <li>
                    <form method="POST" action="{{ route('logout') }}" id="logout-form">
                        @csrf
                        <a href="#" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                            <i class="bi bi-box-arrow-right nav-icon"></i>
                            <span>Logout</span>
                        </a>
                    </form>
                </li>
            </ul>
        </nav>

        <!-- Page Content -->
        <div id="content" :class="{ 'active': sidebarActive }">
            <nav class="navbar navbar-expand-lg navbar-light">
                <div class="container-fluid">
                    <button type="button" @click="sidebarActive = !sidebarActive" class="btn btn-primary d-inline-block">
                        <i class="bi bi-list"></i>
                    </button>
                    
                    <div class="ms-auto d-flex align-items-center">
                        <span class="navbar-text me-3 fw-bold text-dark">
                            @isset($header)
                                {{ $header }}
                            @else
                                Dashboard
                            @endisset
                        </span>
                        <span class="badge bg-light text-dark rounded-pill py-2 px-3 border border-secondary-subtle">
                            <i class="bi bi-person-fill me-1"></i> {{ auth()->user()->name }}
                        </span>
                    </div>
                </div>
            </nav>

            <main class="container-fluid py-4 px-lg-4">
                {{ $slot }}
            </main>
        </div>
    </div>
</body>
</html>
