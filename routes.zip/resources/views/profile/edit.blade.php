<x-app-layout>
    <x-slot name="header">
        <h2 class="h4 font-weight-bold text-dark mb-0">
            {{ __('Profile Settings') }}
        </h2>
    </x-slot>

    <div class="py-5 bg-light min-vh-100">
        <div class="container max-w-4xl mx-auto px-4">
            <div class="row g-4">
                <div class="col-12">
                    <div class="card shadow-sm border-0 rounded-4 p-4">
                        <div class="max-w-xl">
                            @include('profile.partials.update-profile-information-form')
                        </div>
                    </div>
                </div>

                <div class="col-12">
                    <div class="card shadow-sm border-0 rounded-4 p-4">
                        <div class="max-w-xl">
                            @include('profile.partials.update-password-form')
                        </div>
                    </div>
                </div>

                <div class="col-12">
                    <div class="card shadow-sm border-0 rounded-4 p-4 border-danger-subtle">
                        <div class="max-w-xl">
                            @include('profile.partials.delete-user-form')
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <style>
        .max-w-xl { max-width: 36rem; }
        .rounded-4 { border-radius: 1rem !important; }
    </style>
</x-app-layout>
